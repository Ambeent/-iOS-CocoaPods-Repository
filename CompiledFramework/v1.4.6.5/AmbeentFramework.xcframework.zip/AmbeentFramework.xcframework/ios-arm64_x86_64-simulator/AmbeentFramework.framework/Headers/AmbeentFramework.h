//
//  AmbeentFramework.h
//  AmbeentFramework
//
//  Created by Ambeent Inc. on 4.08.2020.
//  Copyright © 2020 Burak Gavas. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SimplePing.h"


//! Project version number for AmbeentFramework.
FOUNDATION_EXPORT double AmbeentFrameworkVersionNumber;

//! Project version string for AmbeentFramework.
FOUNDATION_EXPORT const unsigned char AmbeentFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmbeentFramework/PublicHeader.h>

